<div class="footer">
	<div class="container center">
		<div class="col-lg-12">
			<div class="col-lg-4"><h4>andrewblesener@gmail.com</h4></div>
			<div class="col-lg-4"><h4>Art By Blind &#169;</h4></div>
			<div class="col-lg-4"><h4>651-492-7164</h4></div>
		</div>
	</div>
</div>