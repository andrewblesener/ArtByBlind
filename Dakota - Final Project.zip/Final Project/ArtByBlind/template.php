<?php include('connect.php'); ?>
<!doctype html>
<html>
<head>
<?php include('head.php');?>
</head>
<body>
<?php include('nav.php');?>
<?php include('footer.php'); ?>
</body>
</html>